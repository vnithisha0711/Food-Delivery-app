package com.cg.foodapp.service;

import java.util.List;

import com.cg.foodapp.dto.FoodItemsDTO;

public interface FoodItemsService {

	public FoodItemsDTO addFoodItems(FoodItemsDTO foodItemsDTO);

	public FoodItemsDTO updateFoodItems(FoodItemsDTO foodItemsDTO);

	public boolean deleteFoodItems(FoodItemsDTO foodItemsDTO);

	public FoodItemsDTO getById(int id);

	public List<FoodItemsDTO> findAll();
}
