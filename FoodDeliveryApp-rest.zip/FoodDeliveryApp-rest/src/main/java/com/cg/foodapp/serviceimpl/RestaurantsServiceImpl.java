package com.cg.foodapp.serviceimpl;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.foodapp.dto.RestaurantsDTO;

import com.cg.foodapp.entity.Restaurants;
import com.cg.foodapp.exceptions.RestaurantNotAvailableException;
import com.cg.foodapp.repository.RestaurantsRepository;
import com.cg.foodapp.service.RestaurantsService;

@Service
public class RestaurantsServiceImpl implements RestaurantsService {
	@Autowired
	private RestaurantsRepository repository;

	@Override
	public RestaurantsDTO addRestaurants(RestaurantsDTO restaurantsDTO) {
		
		Restaurants restaurants = new Restaurants();
		BeanUtils.copyProperties(restaurantsDTO, restaurants);
		repository.save(restaurants);
		return restaurantsDTO;
	}

	@Override
	public RestaurantsDTO updateRestaurants(RestaurantsDTO restaurantsDTO) {
		
		Restaurants restaurants = new Restaurants();
		BeanUtils.copyProperties(restaurantsDTO, restaurants);
		repository.save(restaurants);
		return restaurantsDTO;
	}

	@Override
	public boolean deleteRestaurants(RestaurantsDTO restaurantsDTO) {
		
		Restaurants restaurants = new Restaurants();
		BeanUtils.copyProperties(restaurantsDTO, restaurants);
		repository.delete(restaurants);
		return true;
	}



	@Override
	public RestaurantsDTO getById(int id) {
		
		Optional<Restaurants> restaurants = repository.findById(id);
		if (restaurants.isPresent()) {
			RestaurantsDTO dto = new RestaurantsDTO();
			BeanUtils.copyProperties(restaurants.get(), dto);
			return dto;
		}
		throw new RestaurantNotAvailableException("Restaurant not Available");
	}

	@Override
	public List<RestaurantsDTO> findAll() {
		
		Iterable<Restaurants> restaurants = repository.findAll();
		List<RestaurantsDTO> dtos = new ArrayList<>();
		for (Restaurants restaurant : restaurants) {
			RestaurantsDTO dto = new RestaurantsDTO();
			BeanUtils.copyProperties(restaurant, dto);
			dtos.add(dto);
		}
		return dtos;
	}

}
