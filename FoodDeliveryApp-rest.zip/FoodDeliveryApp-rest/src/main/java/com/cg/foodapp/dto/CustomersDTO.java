package com.cg.foodapp.dto;

public class CustomersDTO {

	private int customerId;
	private String name;
	private String Address;
	private Long phonenumber;
	private String emailId;
	private String password;
	private int userId;

	public CustomersDTO() {
	}

	public CustomersDTO(String name, String address, Long phonenumber, String emailId, String password, int userId) {
		super();
		this.name = name;
		this.Address = address;
		this.phonenumber = phonenumber;
		this.emailId = emailId;
		this.password = password;
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void name(String name) {
		this.name = name;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		this.Address = address;
	}

	public Long getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(Long phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "CustomersDTO [customerId=" + customerId + ", name=" + name + ", Address=" + Address + ", phonenumber="
				+ phonenumber + ", emailId=" + emailId + ", password=" + password + ", userId=" + userId + "]";
	}

	
}
