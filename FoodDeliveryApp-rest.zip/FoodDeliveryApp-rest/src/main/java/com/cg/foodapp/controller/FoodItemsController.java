package com.cg.foodapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.foodapp.dto.FoodItemsDTO;
import com.cg.foodapp.exceptions.ItemNotAvailableException;
import com.cg.foodapp.service.FoodItemsService;

@RestController
@RequestMapping("/api/fooditems/")
public class FoodItemsController {

	@Autowired
	public FoodItemsService fooditemsService;
	
	@PostMapping
	public ResponseEntity<FoodItemsDTO> addFoodItems(@RequestBody FoodItemsDTO foodItemsDTO){
		
			FoodItemsDTO fooditems = fooditemsService.addFoodItems(foodItemsDTO);
			return ResponseEntity.ok(fooditems);
		
	}

	@GetMapping("/{id}")
	public ResponseEntity<FoodItemsDTO> getfoodItemById(@PathVariable int id){
		FoodItemsDTO foodItemsDTO=fooditemsService.getById(id);
		return new ResponseEntity<FoodItemsDTO>(foodItemsDTO, HttpStatus.FOUND);
	}
	
	@PutMapping
	public ResponseEntity<FoodItemsDTO> updateFoodItems(@RequestBody FoodItemsDTO foodItemsDTO){
		return new ResponseEntity<FoodItemsDTO>(fooditemsService.updateFoodItems(foodItemsDTO), HttpStatus.ACCEPTED);
		
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Boolean> deleteFoodItemsById(@PathVariable int id){
		FoodItemsDTO foodItemsDTO=fooditemsService.getById(id);
		if(foodItemsDTO!=null) {
			fooditemsService.deleteFoodItems(foodItemsDTO);
			return new ResponseEntity<Boolean>(true, HttpStatus.ACCEPTED);
		}
		throw new ItemNotAvailableException("FoodItems with id " +id+ "doesnot exists");
	}
	
	@GetMapping
	public ResponseEntity<List<FoodItemsDTO>> getAllFoodItems(){
		List<FoodItemsDTO> list=fooditemsService.findAll();
		return ResponseEntity.ok(list);
	}
}
