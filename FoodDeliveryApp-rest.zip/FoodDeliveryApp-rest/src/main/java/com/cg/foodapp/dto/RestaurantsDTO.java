package com.cg.foodapp.dto;

import com.cg.foodapp.entity.FoodItems;
import com.cg.foodapp.entity.Orders;
import com.cg.foodapp.entity.Payment;

public class RestaurantsDTO {

	private int id;
	private String name;
	private String Location;
	private double price;
	private FoodItems fooditems;
	private Payment payment;
	private Orders order;
	private int userId;

	public RestaurantsDTO() {
	}

	public RestaurantsDTO(int id, String name, String location, double price, FoodItems fooditems, Payment payment,
			Orders order, int userId) {
		super();
		this.id = id;
		this.name = name;
		this.Location = location;
		this.price = price;
		this.fooditems = fooditems;
		this.payment = payment;
		this.order = order;
		this.userId = userId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		this.Location = location;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public FoodItems getFooditems() {
		return fooditems;
	}

	public void setFooditems(FoodItems fooditems) {
		this.fooditems = fooditems;
	}

	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}

	public Orders getOrders() {
		return order;
	}

	public void setOrders(Orders order) {
		this.order = order;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "RestaurantsDTO [id=" + id + ", name=" + name + ", Location=" + Location + ", price=" + price
				+ ", fooditems=" + fooditems + ", payment=" + payment + ", order=" + order + ", userId=" + userId + "]";
	}

	
}
