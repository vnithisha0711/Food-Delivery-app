package com.cg.foodapp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="customer_details")
public class Customers {

	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int customerId;
	private String name;
	private String address;
	private Long phonenumber;
	private String emailId;
	private String password;
	
	
	

//	@OneToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name="payment_id")
//	private Payment payment;
	
	@OneToOne
	@JoinColumn(name="user_id")
	private User userId;
	
	public Customers() {}


	public Customers(String name, String address, Long phonenumber, String emailId,
			String password,int userId) {
		super();
		this.name = name;
		this.address = address;
		this.phonenumber = phonenumber;
		this.emailId = emailId;
		this.password = password;
		//this.userId = userId;
	}




	public String getName() {
		return name;
	}


	public void name(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public Long getPhonenumber() {
		return phonenumber;
	}


	public void setPhonenumber(Long phonenumber) {
		this.phonenumber = phonenumber;
	}


	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public User getUserId() {
		return userId;
	}


	public void setUserId(User userId) {
		this.userId = userId;
	}


	
	
	
	
}
