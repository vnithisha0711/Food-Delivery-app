package com.cg.foodapp.serviceimpl;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.foodapp.dto.UserDTO;
import com.cg.foodapp.entity.User;
import com.cg.foodapp.repository.UserRepository;
import com.cg.foodapp.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository repository;

	@Override
	public UserDTO addUser(UserDTO userDTO) {
		
		User user = new User();
		BeanUtils.copyProperties(userDTO, user);
		repository.save(user);
		return userDTO;
	}

	@Override
	public UserDTO updateUser(UserDTO userDTO) {
		
		User user = new User();
		BeanUtils.copyProperties(userDTO, user);
		repository.save(user);
		return userDTO;
	}

	@Override
	public boolean deleteUser(UserDTO userDTO) {
		
		User user = new User();
		BeanUtils.copyProperties(userDTO, user);
		repository.delete(user);
		return true;
	}


	@Override
	public UserDTO getById(int id) {
		
		Optional<User> user = repository.findById(id);
		if (user.isPresent()) {
			UserDTO dto = new UserDTO();
			BeanUtils.copyProperties(user.get(), dto);
			return dto;
		}
		return null;
	}

	@Override
	public List<UserDTO> findAll() {
		
		Iterable<User> user = repository.findAll();
		List<UserDTO> dtos = new ArrayList<>();
		for (User user1 : user) {
			UserDTO dto = new UserDTO();
			BeanUtils.copyProperties(user1, dto);
			dtos.add(dto);
		}
		return dtos;
	}

}
