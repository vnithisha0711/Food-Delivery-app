package com.cg.foodapp.exceptions;

public class RestaurantNotAvailableException extends RuntimeException{


	private static final long serialVersionUID = 1L;

	public RestaurantNotAvailableException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RestaurantNotAvailableException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
