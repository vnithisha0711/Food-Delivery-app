package com.cg.foodapp.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "order_details")
public class Orders {

	@Id
	private String orderId;
	private LocalDate date;
	private double price;
	private String status;
	private int quantity;

	@ManyToOne
	@JoinColumn(name = "customer_id")
	private Customers customers;

//	@OneToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name="payment_id")
//	private Payment payment;

	@ManyToOne
	@JoinColumn(name = "restaurant_id")
	private Restaurants restaurants;

	public Orders() {
	}

	public Orders(String orderId, LocalDate date, double price, String status, int quantity) {
		super();
		this.orderId = orderId;
		this.date = date;
		this.price = price;
		this.status = status;
		this.quantity = quantity;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
