package com.cg.foodapp.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="food_items")
public class FoodItems {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private int foodId;
	private String name;
	private double price;
	
	
	public FoodItems() {}
	
	
	public FoodItems(int foodId, String name, double price) {
		super();
		this.foodId = foodId;
		this.name = name;
		this.price = price;
	}


	public int getFoodId() {
		return foodId;
	}


	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}

	






//	HashMap<String, Double> Breakfast = new HashMap<>();
//	
//	HashMap<String, Double> Lunch = new HashMap<>();
//	
//	HashMap<String, Double> Dinner = new HashMap<>();
//	
//	HashMap<String, Double> Desserts = new HashMap<>();
//	
//	HashMap<String, Double> Beverages = new HashMap<>();
	
	
}
