package com.cg.foodapp.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "restaurants")
public class Restaurants {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String name;
	private String location;
	private double price;
//	private FoodItems fooditems;
//	private Payment payment;
//	private Orders order;

//	@OneToMany(mappedBy = "restaurants",fetch = FetchType.EAGER)
//	public Set<Orders> orders;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "userId")
	private User userId;

	public Restaurants() {
	}

	public Restaurants(int id, String name, String location, double price, FoodItems fooditems, Orders order,
			User userId) {
		super();
		this.id = id;
		this.name = name;
		this.location = location;
		this.price = price;
//		this.fooditems = fooditems;
//		this.payment = payment;
//		this.order = order;
		// this.userId=userId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

//	public FoodItems getFooditems() {
//		return fooditems;
//	}
//
//
//	public void setFooditems(FoodItems fooditems) {
//		this.fooditems = fooditems;
//	}
//
//
//	public Payment getPayment() {
//		return payment;
//	}
//
//
//	public void setPayment(Payment payment) {
//		this.payment = payment;
//	}
//
//
//	public Orders getOrders() {
//		return order;
//	}
//
//
//	public void setOrders(Orders order) {
//		this.order = order;
//	}

	public User getUserId() {
		return userId;
	}

	public void setUserId(User userId) {
		this.userId = userId;
	}

}
