package com.cg.foodapp.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.foodapp.dto.CustomersDTO;

import com.cg.foodapp.entity.Customers;

import com.cg.foodapp.repository.CustomersRepository;
import com.cg.foodapp.service.CustomersService;

@Service
public class CustomersServiceImpl implements CustomersService {
	@Autowired
	private CustomersRepository repository;

	@Override
	public CustomersDTO addCustomers(CustomersDTO customersDTO) {
		
		Customers customers = new Customers();
		BeanUtils.copyProperties(customersDTO, customers);
		repository.save(customers);
		return customersDTO;
	}

	@Override
	public CustomersDTO updateCustomers(CustomersDTO customersDTO) {
		
		Customers customers = new Customers();
		BeanUtils.copyProperties(customersDTO, customers);
		repository.save(customers);
		return customersDTO;
	}

	@Override
	public boolean deleteCustomers(CustomersDTO customersDTO) {
		
		Customers customers = new Customers();
		BeanUtils.copyProperties(customersDTO, customers);
		repository.delete(customers);
		return true;
	}

	@Override
	public List<CustomersDTO> findAll() {
		
		Iterable<Customers> customers = repository.findAll();
		List<CustomersDTO> dtos = new ArrayList<>();
		for (Customers customer : customers) {
			CustomersDTO dto = new CustomersDTO();
			BeanUtils.copyProperties(customer, dto);
			dtos.add(dto);
		}
		return dtos;

	}

	@Override
	public CustomersDTO getById(int id) {
		
		Optional<Customers> customers = repository.findById(id);
		if (customers.isPresent()) {
			CustomersDTO dto = new CustomersDTO();
			BeanUtils.copyProperties(customers.get(), dto);
			return dto;
		}
		return null;

	}

}
