package com.cg.foodapp.dto;

import java.time.LocalDate;

public class OrdersDTO {

	private String orderId;
	private LocalDate date;
	private double price;
	private String status;
	private int quantity;

	public OrdersDTO() {
	}

	public OrdersDTO(String orderId, LocalDate date, double price, String status, int quantity) {
		super();
		this.orderId = orderId;
		this.date = date;
		this.price = price;
		this.status = status;
		this.quantity = quantity;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "OrdersDTO [orderId=" + orderId + ", date=" + date + ", price=" + price + ", status=" + status
				+ ", quantity=" + quantity + "]";
	}
	
	

}
