package com.cg.foodapp.exceptions;

public class PaymentDeclineException extends RuntimeException{


	private static final long serialVersionUID = 1L;

	public PaymentDeclineException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PaymentDeclineException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
