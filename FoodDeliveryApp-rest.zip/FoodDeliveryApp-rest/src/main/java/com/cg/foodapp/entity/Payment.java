package com.cg.foodapp.entity;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="payment_details")
public class Payment {
	
	
	private String UPI;
	private String CreditCard;
	private String DebitCard;
	private LocalDate date;
	private LocalTime time;
	private double amount;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String paymentId;
	
//	@OneToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name="customer_id")
//	private Customers customers;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="order_id")
	private Orders orders;
	
	public Payment() {}
	
	public Payment(String uPI, String creditCard, String debitCard, LocalDate date, LocalTime time, double amount,
			String paymentId) {
		super();
		UPI = uPI;
		CreditCard = creditCard;
		DebitCard = debitCard;
		this.date = date;
		this.time = time;
		this.amount = amount;
		this.paymentId = paymentId;
	}

	public String getUPI() {
		return UPI;
	}

	public void setUPI(String uPI) {
		UPI = uPI;
	}

	public String getCreditCard() {
		return CreditCard;
	}

	public void setCreditCard(String creditCard) {
		CreditCard = creditCard;
	}

	public String getDebitCard() {
		return DebitCard;
	}

	public void setDebitCard(String debitCard) {
		DebitCard = debitCard;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public LocalTime getTime() {
		return time;
	}

	public void setTime(LocalTime time) {
		this.time = time;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	

	
	

}
